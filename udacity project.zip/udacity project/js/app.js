// udacity project by Yousef Ahmed //

//sourced i got help with { Elzero wep school(YT channel) , W3schools (wepsite)}

// define variables
let navB = document.getElementById('ul1');
let sections = document.querySelectorAll('section');

// main function
onscroll = function(){
    let scrollPage = this.document.documentElement.scrollTop;
    sections.forEach((S) => {
        if(
            // to make to scroll begin before the end of the section :)
            scrollPage >= S.offsetTop - S.offsetHeight *0.15 &&
            scrollPage <
              S.offsetTop + S.offsetHeight - S.offsetHeight * 0.15
        ){
            // giving id for the activated class
            let ID = S.attributes.id.value;
            removeAllActiveClasses();
            addActiveClass(ID);
        }
    });
};  
// nav , listitem builder
let navBuilder = () =>{
    let nav ='';
    sections.forEach(S => {
        let SID = S.id;
        let SDN = S.dataset.nav;
        // creat list item
        nav += `<li><a class="li1" href="#${SID}">${SDN}</a></li>`;
    });
    navB.innerHTML = nav;
};
navBuilder();

// remove active class
let removeAllActiveClasses = function () {
    document.querySelectorAll("nav a").forEach((R) => {
        R.classList.remove("active");
    });
};

//add active class
let addActiveClass = function (A) {
    let SR = `nav a[href="#${A}"]`;
    document.querySelector(SR).classList.add("active");
};

//navlinlks
let NL = document.querySelectorAll("nav a");
NL.forEach((K) => {
    K.addEventListener("click", (S) => {
        S.preventDefault();
        let current = S.target.attributes.href.value;
        let section = document.querySelector(current);
        let sectionP = section.offsetTop;
        // smooth scrolling
        window.scroll({
            top: sectionP,
            behavior: "smooth",
        });
    });
});
//end :)

